// lines is minimal text editor in rust
// cargo build --profile release-small

/*
This code is under construction!

some code below may not be correct or current.

### Phase 1: Foundation (Do First)
[done?] 1. **Fix EditorState** - Add any missing window tracking fields
[done?] 2. **Add line buffers** - Pre-allocated display-line buffers
[done?] 3. **Create test file** - Make a test file with known content for testing
[done?] 4. **Add basic file reader** - Just `read_forward_chars()` to start

[done?] ### Phase 2: Display Window (No scrolling yet)
[done?] 5. **Build build_windowmap_nowrap() function** - Read file, fill [done?] display buffers with line numbers + text
[done?] - finish updating buffer window sizes

[done?] 6. **Display window function** - Print display buffers to terminal
[done?] 7. **Test** - Show first 21 lines of a file with line numbers

- Test double-wide character mapping
(I don't care about packing more char into the TUI, but errors are bad)

TODO:
- save test files to CDW
- keep test files for manual inspection
- use absolute paths
- do not use hidden OS temp directory
- show absolute path:
Test file path: "/tmp/lines_editor_tests_test_build_windowmap_nowrap_basic/basic_short.txt"
- Do not delete any user files ever.




### Phase 3: Navigation
1. clean up TUI
- remove clutter (no filler lines)
- add legend top bar
- possibly bottom info bar with path & info, cursor-position in file
window state summary: line, position, mode.
maybe command on info-bar line, not under it

2. Add cursor etc. (from POC)
- move-N spaces (in POC)
- select code (even if select doesn't do anything now) (in POC)
3. **Add scroll down** - Increment line number, rebuild window
4. **Add scroll up** - Decrement line number, rebuild window
5. **Test** - Verify line numbers track correctly
6. scroll right (see unwrapped long lines)
7. scroll back to left
### Phase 4: Line-Wrap Mode
1. fn checks state for wrap-mode toggle
and then uses the correct build-window-map function...easy?
2. **Add wrap detection** - Check if line exceeds 77 chars
3. **Handle wrapped display** - Split line across multiple display buffers
### Phase 5: edit
1. write char
2. delete char
3. delete line



Rust rules:
Always best practice.
Always extensive doc strings.
Always comments.
Always cargo tests (where possible).
Never remove documentation.
Always clear, meaningful, unique names (e.g. variables, functions).
Always absolute file paths.
Always error handling.
Never unsafe code.
Never use unwrap.

Load what is needed when it is needed: Do not ever load a whole file, rarely load a whole anything. increment and load only what is required pragmatically.

Following NASA's 'Power of 10 rules' (updated for 2025 and Rust):
1. no unsafe stuff:
- no recursion
- no goto
- no pointers
- no preprocessor

2. upper bound on normal-loops, failsafe for always-loops

3. Pre-allocate all memory (no dynamic memory allocation)

4. functions have narrow focus
s
5. Defensive programming:
- average to a minimum of two assertions per function
- cargo tests
- error handling details
- uses of Option


6. ? Is this about ownership of variables?

7. manage return values:
null-void return values & checking non-void-null returns

8.
9. Communicate:
doc strings, comments, use case, edge case,


Always defensive best practice:
Always error handling: everything will fail at some point, if only because of cosmic-ray bit-flips (which are actually common), there must always be fail-safe error handling.

Safety, reliability, maintainability, fail-safe, communication-documentation, are the goals.

No third party libraries (or strictly avoid third party libraries where possible).

*/

/*
POC cursor system


// ANSI escape codes
const CLEAR_SCREEN: &str = "\x1b[2J";
const RESET_CURSOR: &str = "\x1b[H";
const RESET_STYLE: &str = "\x1b[0m";
const BOLD: &str = "\x1b[1m";
const RED: &str = "\x1b[31m";
const GREEN: &str = "\x1b[32m";
const BLUE: &str = "\x1b[34m";
const YELLOW: &str = "\x1b[33m";
// const CYAN: &str = "\x1b[36m";
const BG_WHITE: &str = "\x1b[47m";
// const BG_BLACK: &str = "\x1b[40m";
// const BG_YELLOW: &str = "\x1b[43m";
const BG_CYAN: &str = "\x1b[46m";

fn move_cursor_to(x: usize, y: usize) {
    print!("\x1b[{};{}H", y + 1, x + 1);
}

fn parse_command(input: &str) -> (Option<char>, usize) {
    let trimmed = input.trim();
    if trimmed.is_empty() {
        return (None, 1);
    }

    let chars: Vec<char> = trimmed.chars().collect();
    if chars.len() == 1 {
        return (Some(chars[0]), 1);
    }

    if let Some(first_char) = chars.first() {
        if "hjklweb".contains(*first_char) {
            let number_part: String = chars[1..].iter().collect();
            if let Ok(count) = number_part.parse::<usize>() {
                return (Some(*first_char), count.min(100));
            }
        }
    }

    (Some(chars[0]), 1)
}

fn is_word_char(ch: char) -> bool {
    ch.is_alphanumeric() || ch == '_'
}

fn find_word_end(line: &[char], start_x: usize) -> usize {
    if start_x >= line.len() {
        return start_x;
    }

    let mut x = start_x;

    // If we're on a word character, skip to end of current word
    if x < line.len() && is_word_char(line[x]) {
        while x < line.len() && is_word_char(line[x]) {
            x += 1;
        }
        if x < line.len() {
            return x - 1; // Position on last char of word
        }
        return x.saturating_sub(1);
    }

    // Skip non-word characters
    while x < line.len() && !is_word_char(line[x]) {
        x += 1;
    }

    // Find end of next word
    while x < line.len() && is_word_char(line[x]) {
        x += 1;
    }

    x.saturating_sub(1).min(line.len().saturating_sub(1))
}

fn find_word_beginning(line: &[char], start_x: usize) -> usize {
    if line.is_empty() || start_x == 0 {
        return 0;
    }

    let mut x = start_x.min(line.len().saturating_sub(1));

    // If we're on a word character and not at the beginning of a word, go to current word's beginning
    if x > 0 && x < line.len() && is_word_char(line[x]) && is_word_char(line[x - 1]) {
        while x > 0 && is_word_char(line[x - 1]) {
            x -= 1;
        }
        return x;
    }

    // Skip backward over non-word characters
    while x > 0 && !is_word_char(line[x.min(line.len() - 1)]) {
        x -= 1;
    }

    // Find beginning of previous word
    while x > 0 && is_word_char(line[x]) {
        x -= 1;
    }

    if x > 0 || !is_word_char(line[0]) {
        x + 1
    } else {
        0
    }
}

fn find_next_word_start(line: &[char], start_x: usize) -> usize {
    if start_x >= line.len() {
        return line.len();
    }

    let mut x = start_x;

    // Skip current word
    while x < line.len() && is_word_char(line[x]) {
        x += 1;
    }

    // Skip spaces/punctuation
    while x < line.len() && !is_word_char(line[x]) {
        x += 1;
    }

    x
}

#[derive(Debug, Clone, Copy, PartialEq)]
struct Position {
    x: usize,
    y: usize,
}

fn main() {
    let mut cursor = Position { x: 0, y: 0 };
    let mut selection_start: Option<Position> = None;
    let mut selection_end: Option<Position> = None;
    let mut visual_mode = false;

    let mut content: Vec<Vec<char>> = vec![
        "Hello, World! This is a test.".chars().collect(),
        "This is a minimal editor with selections".chars().collect(),
        "Use hjkl to move cursor, w/e/b for words".chars().collect(),
        "Press v to start/stop visual mode".chars().collect(),
        "Press q + Enter to quit".chars().collect(),
        "foo_bar baz-qux some.text here".chars().collect(),
        "".chars().collect(),
    ];

    while content.len() < 24 {
        content.push(Vec::new());
    }

    let stdin = io::stdin();
    let mut handle = stdin.lock();
    let mut last_command_info = String::new();

    loop {
        print!("{}{}", CLEAR_SCREEN, RESET_CURSOR);

        // Draw the content with selection highlighting
        for (y, line) in content.iter().enumerate() {
            if y >= 24 {
                break;
            }

            move_cursor_to(0, y);

            for (x, &ch) in line.iter().enumerate() {
                if x >= 80 {
                    break;
                }

                let pos = Position { x, y };
                let is_cursor = x == cursor.x && y == cursor.y;

                // Check if position is in selection
                let in_selection =
                    if let (Some(start), Some(end)) = (selection_start, selection_end) {
                        // Handle multi-line selection
                        if start.y == end.y {
                            y == start.y && x >= start.x.min(end.x) && x <= start.x.max(end.x)
                        } else if start.y < end.y {
                            (y == start.y && x >= start.x)
                                || (y > start.y && y < end.y)
                                || (y == end.y && x <= end.x)
                        } else {
                            (y == end.y && x >= end.x)
                                || (y > end.y && y < start.y)
                                || (y == start.y && x <= start.x)
                        }
                    } else {
                        false
                    };

                if is_cursor {
                    print!("{}{}{}{}{}", BOLD, RED, BG_WHITE, ch, RESET_STYLE);
                } else if in_selection {
                    print!("{}{}{}{}{}", BOLD, YELLOW, BG_CYAN, ch, RESET_STYLE);
                } else {
                    print!("{}", ch);
                }
            }

            // Show cursor if beyond line end
            if cursor.x >= line.len() && y == cursor.y {
                move_cursor_to(cursor.x, y);
                print!("{}{}{} {}", BOLD, RED, BG_WHITE, RESET_STYLE);
            }

            // Highlight empty space in selection
            if let (Some(start), Some(end)) = (selection_start, selection_end) {
                let line_len = line.len();
                if y >= start.y.min(end.y) && y <= start.y.max(end.y) {
                    let selection_end_x = if y == end.y.max(start.y) {
                        end.x.max(start.x)
                    } else {
                        79
                    };

                    for x in line_len..=selection_end_x.min(79) {
                        if x == cursor.x && y == cursor.y {
                            continue; // Already drawn cursor
                        }
                        move_cursor_to(x, y);
                        print!("{}{}{} {}", BOLD, YELLOW, BG_CYAN, RESET_STYLE);
                    }
                }
            }
        }

        // Status lines
        move_cursor_to(0, 22);
        print!(
            "{}{}Pos: ({},{}) | Mode: {} | Last: {} {}",
            BOLD,
            BLUE,
            cursor.x,
            cursor.y,
            if visual_mode { "VISUAL" } else { "NORMAL" },
            last_command_info,
            RESET_STYLE
        );

        move_cursor_to(0, 23);
        print!(
            "{}{}Commands: hjkl=move, w/e/b=word, v=visual, q=quit | Enter: {}",
            BOLD, GREEN, RESET_STYLE
        );

        io::stdout().flush().unwrap();

        let mut input = String::new();
        handle.read_line(&mut input).unwrap();
        let (command, repeat_count) = parse_command(&input);

        if let Some(cmd) = command {
            let old_cursor = cursor;

            match cmd {
                'h' => {
                    let moves = repeat_count.min(cursor.x);
                    cursor.x -= moves;
                    last_command_info = format!("Left {}", moves);
                }
                'l' => {
                    let moves = repeat_count.min(79 - cursor.x);
                    cursor.x += moves;
                    last_command_info = format!("Right {}", moves);
                }
                'k' => {
                    let moves = repeat_count.min(cursor.y);
                    cursor.y -= moves;
                    last_command_info = format!("Up {}", moves);
                }
                'j' => {
                    let moves = repeat_count.min(23 - cursor.y);
                    cursor.y += moves;
                    last_command_info = format!("Down {}", moves);
                }
                'w' => {
                    // Move to next word start
                    for _ in 0..repeat_count {
                        if cursor.y < content.len() {
                            let new_x = find_next_word_start(&content[cursor.y], cursor.x);
                            cursor.x = new_x.min(79);
                        }
                    }
                    last_command_info = format!("Word forward {}", repeat_count);
                }
                'e' => {
                    // Move to word end
                    for _ in 0..repeat_count {
                        if cursor.y < content.len() {
                            let new_x = find_word_end(&content[cursor.y], cursor.x);
                            cursor.x = new_x.min(79);
                        }
                    }
                    last_command_info = format!("Word end {}", repeat_count);
                }
                'b' => {
                    // Move to word beginning
                    for _ in 0..repeat_count {
                        if cursor.y < content.len() {
                            cursor.x = find_word_beginning(&content[cursor.y], cursor.x);
                        }
                    }
                    last_command_info = format!("Word back {}", repeat_count);
                }
                'v' => {
                    // Toggle visual mode
                    visual_mode = !visual_mode;
                    if visual_mode {
                        selection_start = Some(cursor);
                        selection_end = Some(cursor);
                        last_command_info = "Visual mode ON".to_string();
                    } else {
                        selection_start = None;
                        selection_end = None;
                        last_command_info = "Visual mode OFF".to_string();
                    }
                }
                'q' => {
                    print!("{}{}", CLEAR_SCREEN, RESET_CURSOR);
                    println!("Goodbye!");
                    break;
                }
                _ => {
                    last_command_info = format!("Unknown: {}", cmd);
                }
            }

            // Update selection end if in visual mode and cursor moved
            if visual_mode && cursor != old_cursor {
                selection_end = Some(cursor);
            }
        }
    }
}
 */

use std::env;
use std::fs::{self, File, OpenOptions};
use std::io::{self, BufRead, BufReader, Write};
use std::path::{Path, PathBuf};

/// state.rs - Core editor state management with pre-allocated buffers
///
/// This module manages all editor state using only pre-allocated memory.
/// No dynamic allocation is performed after initialization.
/// All operations are bounds-checked and error-handled.
///
/// Maximum buffer size for window content is (2^13 = 8192 bytes)
///
/// Sorry: The calculation is not simple,
/// a 80x24 terminal size 3 minus header, 3 footer, line-number * 4
/// is (rows, cols) 45*157 TUI-text size * 3-bytes UTF-8
///
/// default normal size is 77*21 = 1617 bytes
/// but most of that is empty space, likely ~800 character bytes.
///
/// Also, as line number grows, more columns lost to that
///
const WINDOW_BUFFER_SIZE: usize = 8192; // 2**13=8192

/// Maximum number of rows (lines) in largest supported terminal
const MAX_ROWS: usize = 45;

/// Maximum number of columns (utf-8 char across) in largest supported TUI
const MAX_COLS: usize = 157;

/// Default TUI text dimensions + 3 header footer,
/// + at least 3 for line numbers
const DEFAULT_ROWS: usize = 21;
const DEFAULT_COLS: usize = 77;

/// Represents a position in the file (not in the window)
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct FilePosition {
    /// Byte offset from start of file
    pub byte_offset: u64,
    /// Line number (0-indexed)
    pub line_number: usize,
    /// Byte offset within the line
    pub byte_in_line: usize,
}

/// Represents a position in the terminal window
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WindowPosition {
    /// Row in terminal (0-indexed, 0-95 max)
    pub row: usize,
    /// Column in terminal (0-indexed, 0-319 max)
    pub col: usize,
}

/// Maps window positions to file positions
pub struct WindowMap {
    /// Pre-allocated mapping array [row][col] -> Option<FilePosition>
    /// None means this position is empty/padding
    positions: [[Option<FilePosition>; MAX_COLS]; MAX_ROWS],
    /// Number of valid rows in current window
    valid_rows: usize,
    /// Number of valid columns in current window
    valid_cols: usize,
}

impl WindowMap {
    /// Creates a new WindowMap with all positions set to None
    pub fn new() -> Self {
        WindowMap {
            positions: [[None; MAX_COLS]; MAX_ROWS],
            valid_rows: DEFAULT_ROWS,
            valid_cols: DEFAULT_COLS,
        }
    }

    /// Gets the file position for a window position
    ///
    /// # Arguments
    /// * `row` - Terminal row (0-indexed)
    /// * `col` - Terminal column (0-indexed)
    ///
    /// # Returns
    /// * `Ok(Option<FilePosition>)` - File position if valid, None if empty
    /// * `Err(io::Error)` - If row/col out of bounds
    pub fn get_file_position(&self, row: usize, col: usize) -> io::Result<Option<FilePosition>> {
        // Defensive: Check bounds
        if row >= self.valid_rows {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!("Row {} exceeds valid rows {}", row, self.valid_rows),
            ));
        }
        if col >= self.valid_cols {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!("Column {} exceeds valid columns {}", col, self.valid_cols),
            ));
        }

        Ok(self.positions[row][col])
    }

    /// Sets the file position for a window position
    ///
    /// # Arguments
    /// * `row` - Terminal row (0-indexed)
    /// * `col` - Terminal column (0-indexed)
    /// * `file_pos` - File position to map to (None for empty)
    ///
    /// # Returns
    /// * `Ok(())` - Successfully set
    /// * `Err(io::Error)` - If row/col out of bounds
    pub fn set_file_position(
        &mut self,
        row: usize,
        col: usize,
        file_pos: Option<FilePosition>,
    ) -> io::Result<()> {
        // Defensive: Check bounds
        if row >= MAX_ROWS {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!("Row {} exceeds maximum {}", row, MAX_ROWS),
            ));
        }
        if col >= MAX_COLS {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!("Column {} exceeds maximum {}", col, MAX_COLS),
            ));
        }

        self.positions[row][col] = file_pos;
        Ok(())
    }

    /// Clears all mappings
    pub fn clear(&mut self) {
        // Defensive: explicit loop with bounds
        for row in 0..MAX_ROWS {
            for col in 0..MAX_COLS {
                self.positions[row][col] = None;
            }
        }
    }
}

/// Current editor mode
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum EditorMode {
    /// Normal/command mode (like vim normal mode)
    Normal,
    /// Insert mode for typing
    Insert,
    /// Visual selection mode
    Visual,
    /// Multi-cursor mode (ctrl+d equivalent)
    MultiCursor,
}

/// Line wrap mode setting
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum WrapMode {
    /// Lines wrap at terminal width
    Wrap,
    /// Lines extend beyond terminal width (horizontal scroll)
    NoWrap,
}

/// Main editor state structure with all pre-allocated buffers
pub struct EditorState {
    /// Current editor mode
    pub mode: EditorMode,

    /// Line wrap setting
    pub wrap_mode: WrapMode,

    /// Absolute path to the file being edited
    pub file_path: Option<PathBuf>,

    /// Absolute path to read-copy of file
    pub read_copy_path: Option<PathBuf>,

    /// Terminal dimensions
    pub terminal_rows: usize,
    pub terminal_cols: usize,

    /// Effective editing area (minus headers/footers/line numbers)
    pub effective_rows: usize,
    pub effective_cols: usize,

    /// Current window buffer containing visible text
    /// Pre-allocated to WINDOW_BUFFER_SIZE
    pub window_buffer: [u8; WINDOW_BUFFER_SIZE],

    /// Number of valid bytes in window_buffer
    pub window_buffer_used: usize,

    /// Window to file position mapping
    pub window_map: WindowMap,

    /// Cursor position in window
    pub cursor: WindowPosition,

    /// File position of top-left corner of window
    pub window_start: FilePosition,

    /// Visual mode selection start (if in visual mode)
    pub selection_start: Option<FilePosition>,

    /// Path to .changelog file
    pub changelog_path: Option<PathBuf>,

    /// Flag indicating if file has unsaved changes
    pub is_modified: bool,

    // === WINDOW POSITION TRACKING ===
    /// Line number of file that appears at top of terminal window
    /// Example: If window shows from line 500, this is 500
    pub line_count_at_top_of_window: usize,

    /// Byte position in file where the top display line starts
    /// Example: Line 500 starts at byte 12048 in the file
    pub file_position_of_topline_start: u64,

    /// For LineWrap mode: byte offset within the line where window starts
    /// Example: If line 500 has 300 chars and we're showing the 3rd wrap, this might be 211
    pub linewrap_window_topline_startbyte_position: u64,

    /// For LineWrap mode: character offset within the line where window starts
    /// Example: Starting at character 70 of line 500
    pub linewrap_window_topline_char_offset: usize,

    /// For NoWrap mode: horizontal character offset for all displayed lines
    /// Example: Showing characters 20-97 of each line
    pub horizontal_line_char_offset: usize,

    // === DISPLAY BUFFERS ===
    /// Pre-allocated buffers for each display row (45 rows × 80 chars)
    /// Each buffer holds one terminal row including line number and text
    pub display_buffers: [[u8; 182]; 45],

    /// Actual bytes used in each display buffer
    /// Since lines can be shorter than 80 chars, we track actual usage
    pub display_buffer_lengths: [usize; 45],
}

impl EditorState {
    /// Creates a new EditorState with all memory pre-allocated
    ///
    /// # Returns
    /// * `EditorState` - Initialized state with default values
    pub fn new() -> Self {
        // Calculate effective area (3 cols for line numbers, 3 rows for header/footer)
        let effective_cols = DEFAULT_COLS.saturating_sub(3);
        let effective_rows = DEFAULT_ROWS.saturating_sub(3);

        EditorState {
            mode: EditorMode::Normal,
            wrap_mode: WrapMode::Wrap,
            file_path: None,
            read_copy_path: None,
            terminal_rows: DEFAULT_ROWS,
            terminal_cols: DEFAULT_COLS,
            effective_rows,
            effective_cols,
            window_buffer: [0u8; WINDOW_BUFFER_SIZE],
            window_buffer_used: 0,
            window_map: WindowMap::new(),
            cursor: WindowPosition { row: 0, col: 0 },
            window_start: FilePosition {
                byte_offset: 0,
                line_number: 0,
                byte_in_line: 0,
            },
            selection_start: None,
            changelog_path: None,
            is_modified: false,

            // === NEW FIELD INITIALIZATION ===
            // Window position tracking - start at beginning of file
            line_count_at_top_of_window: 0,
            file_position_of_topline_start: 0,
            linewrap_window_topline_startbyte_position: 0,
            linewrap_window_topline_char_offset: 0,
            horizontal_line_char_offset: 0,

            // Display buffers - initialized to zero
            display_buffers: [[0u8; 182]; 45],
            display_buffer_lengths: [0usize; 45],
        }
    }

    /// Initialize changelog for the current file
    pub fn init_changelog(&mut self, file_path: &Path) -> io::Result<()> {
        // Put changelog next to the file: "document.txt.changelog"
        self.changelog_path = Some(file_path.with_extension("txt.changelog"));
        Ok(())
    }

    /// Append an edit operation to the changelog
    pub fn log_edit(&self, operation: &str) -> io::Result<()> {
        if let Some(ref log_path) = self.changelog_path {
            use std::fs::OpenOptions;
            use std::io::Write;

            let mut file = OpenOptions::new()
                .create(true)
                .append(true)
                .open(log_path)?;

            writeln!(file, "{}", operation)?;
        }
        Ok(())
    }

    /*
    // When opening a file:
    state.init_changelog(&file_path)?;

    // When user types/edits:
    state.log_edit(&format!("INSERT {} {}: {}", line_num, byte_pos, text))?;

    // When user deletes:
    state.log_edit(&format!("DELETE {} {}: {}", line_num, byte_pos, deleted_text))?;
     */

    /// Clears all display buffers and resets their lengths
    ///
    /// # Purpose
    /// Called before rebuilding window content to ensure clean slate
    /// Defensive programming: explicitly zeros all buffers
    pub fn clear_display_buffers(&mut self) {
        // Defensive: Clear each buffer completely
        for row_idx in 0..45 {
            for col_idx in 0..80 {
                self.display_buffers[row_idx][col_idx] = 0;
            }
            self.display_buffer_lengths[row_idx] = 0;
        }
    }

    /// Writes a line number into a display buffer
    ///
    /// # Format
    /// Just the line number and ONE space. No padding, no alignment.
    /// - Line 1: "1 " (2 bytes)
    /// - Line 42: "42 " (3 bytes)
    /// - Line 999: "999 " (4 bytes)
    pub fn write_line_number(&mut self, row_idx: usize, line_num: usize) -> io::Result<usize> {
        // Defensive: Validate row index
        if row_idx >= 45 {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!("Row index {} exceeds maximum 44", row_idx),
            ));
        }

        // Format: just the number and one space, NO PADDING
        let line_str = format!("{} ", line_num);
        let line_bytes = line_str.as_bytes();

        // Copy to buffer
        let bytes_to_write = line_bytes.len().min(182); // Safety check against buffer size
        self.display_buffers[row_idx][..bytes_to_write]
            .copy_from_slice(&line_bytes[..bytes_to_write]);

        Ok(bytes_to_write)
    }

    /// Updates terminal dimensions and recalculates effective area
    ///
    /// # Arguments
    /// * `rows` - New terminal row count
    /// * `cols` - New terminal column count
    ///
    /// # Returns
    /// * `Ok(())` - Successfully updated
    /// * `Err(io::Error)` - If dimensions exceed maximums
    pub fn resize_terminal(&mut self, rows: usize, cols: usize) -> io::Result<()> {
        // Defensive: Validate dimensions
        if rows > MAX_ROWS {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!("Rows {} exceeds maximum {}", rows, MAX_ROWS),
            ));
        }
        if cols > MAX_COLS {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!("Columns {} exceeds maximum {}", cols, MAX_COLS),
            ));
        }

        self.terminal_rows = rows;
        self.terminal_cols = cols;

        // Recalculate effective area (reserve space for UI elements)
        self.effective_rows = rows.saturating_sub(3);
        self.effective_cols = cols.saturating_sub(3);

        // Update window map dimensions
        self.window_map.valid_rows = self.effective_rows;
        self.window_map.valid_cols = self.effective_cols;

        Ok(())
    }

    /// Clears the window buffer and map
    pub fn clear_window(&mut self) {
        // Clear buffer
        for i in 0..WINDOW_BUFFER_SIZE {
            self.window_buffer[i] = 0;
        }
        self.window_buffer_used = 0;

        // Clear map
        self.window_map.clear();
    }
}

#[cfg(test)]
mod editor_state_tests {
    use super::*;

    #[test]
    fn test_editor_state_creation() {
        let state = EditorState::new();
        assert_eq!(state.mode, EditorMode::Normal);
        assert_eq!(state.terminal_rows, DEFAULT_ROWS);
        assert_eq!(state.terminal_cols, DEFAULT_COLS);
        assert_eq!(state.window_buffer_used, 0);
        assert!(!state.is_modified);
    }

    #[test]
    fn test_resize_terminal_valid() {
        let mut state = EditorState::new();
        let result = state.resize_terminal(30, 100);
        assert!(result.is_ok());
        assert_eq!(state.terminal_rows, 30);
        assert_eq!(state.terminal_cols, 100);
        assert_eq!(state.effective_rows, 27); // 30 - 3
        assert_eq!(state.effective_cols, 97); // 100 - 3
    }

    #[test]
    fn test_resize_terminal_too_large() {
        let mut state = EditorState::new();
        let result = state.resize_terminal(200, 100); // 200 > MAX_ROWS
        assert!(result.is_err());
    }

    #[test]
    fn test_window_map_bounds_checking() {
        let map = WindowMap::new();

        // Valid access
        let result = map.get_file_position(0, 0);
        assert!(result.is_ok());

        // Out of bounds access
        let result = map.get_file_position(DEFAULT_ROWS, 0);
        assert!(result.is_err());
    }
}

/// Gets a timestamp string in yyyy_mm_dd format using only standard library
fn get_timestamp() -> io::Result<String> {
    let time = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_err(|e| io::Error::new(io::ErrorKind::Other, e))?;

    let secs = time.as_secs();
    let days_since_epoch = secs / (24 * 60 * 60);

    // These arrays help us handle different month lengths
    let days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    let mut year = 1970;
    let mut remaining_days = days_since_epoch;

    // Calculate year
    loop {
        let year_length = if is_leap_year(year) { 366 } else { 365 };
        if remaining_days < year_length {
            break;
        }
        remaining_days -= year_length;
        year += 1;
    }

    // Calculate month and day
    let mut month = 1;
    for (month_idx, &days) in days_in_month.iter().enumerate() {
        let month_length = if month_idx == 1 && is_leap_year(year) {
            29
        } else {
            days
        };

        if remaining_days < month_length {
            break;
        }
        remaining_days -= month_length;
        month += 1;
    }

    let day = remaining_days + 1;

    Ok(format!("{:04}_{:02}_{:02}", year, month, day))
}

/// Helper function to determine if a year is a leap year
/// Determines if a given year is a leap year using the Gregorian calendar rules
///
/// # Arguments
/// * `year` - Year to check (CE/AD)
///
/// # Returns
/// * `bool` - true if leap year, false if not
///
/// # Rules
/// - Year is leap year if divisible by 4
/// - Exception: century years must be divisible by 400
/// - Years divisible by 100 but not 400 are not leap years
fn is_leap_year(year: u64) -> bool {
    if year % 4 != 0 {
        false
    } else if year % 100 != 0 {
        true
    } else if year % 400 != 0 {
        false
    } else {
        true
    }
}

/// Displays the last n lines of a file to standard output
/// Returns an IO Result to properly handle potential file reading errors
///
/// # Arguments
/// * `file_path` - Path to the file to display
/// * `num_lines` - Number of lines to show from end of file
///
/// # Returns
/// * `io::Result<()>` - Success or error status of the display operation
///
/// # Errors
/// Returns error if:
/// - File cannot be opened
/// - File cannot be read
/// - File content cannot be parsed as valid UTF-8
fn memo_mode_display_file_tail(file_path: &Path, num_lines: usize) -> io::Result<()> {
    let file = File::open(file_path)?;
    let reader = BufReader::new(file);
    let lines: Vec<String> = reader.lines().collect::<io::Result<_>>()?;

    let start = if lines.len() > num_lines {
        lines.len() - num_lines
    } else {
        0
    };

    for line in &lines[start..] {
        println!("{}", line);
    }
    Ok(())
}

/// Gets the header string for a new file
/// Combines timestamp with optional header.txt content
///
/// # Returns
/// - `Ok(String)` - Header string containing timestamp and optional header.txt content
/// - `Err(io::Error)` - If there's an error reading header.txt (if it exists)
/// Gets the header string for a new file          // <-- Duplicated line
/// Combines timestamp with optional header.txt content  // <-- Duplicated line
fn get_header_text() -> io::Result<String> {
    let timestamp = get_timestamp()?;
    let mut header = format!("# {}", timestamp);

    // Get the executable's directory
    let exe_path = env::current_exe()?;
    let exe_dir = exe_path.parent().ok_or_else(|| {
        io::Error::new(
            io::ErrorKind::NotFound,
            "Could not determine executable directory",
        )
    })?;

    // Check for header.txt in the executable's directory
    let header_path = exe_dir.join("header.txt");

    // Also check in the current working directory as fallback
    let current_dir_header = Path::new("header.txt");

    if header_path.exists() {
        let header_content = fs::read_to_string(header_path)?;
        header.push_str("  ");
        header.push_str(&header_content);
    } else if current_dir_header.exists() {
        let header_content = fs::read_to_string(current_dir_header)?;
        header.push_str("  ");
        header.push_str(&header_content);
    }

    Ok(header)
}

/// Appends a single line to the file with temporary backup protection
///
/// # Arguments
/// * `file_path` - Path to the file being appended to
/// * `line` - Text line to append
///
/// # Behavior
/// 1. Creates temporary backup
/// 2. Appends the line
/// 3. Removes backup if successful
/// 4. Restores from backup if append fails
fn append_line(file_path: &Path, line: &str) -> io::Result<()> {
    // Create temporary backup before modification
    let backup_path = if file_path.exists() {
        let bak_path = file_path.with_extension("bak");
        fs::copy(file_path, &bak_path)?;
        Some(bak_path)
    } else {
        None
    };

    // Attempt to append the line
    let result = OpenOptions::new()
        .create(true)
        .append(true)
        .open(file_path)
        .and_then(|mut file| writeln!(file, "{}", line));

    // Handle the result
    match result {
        Ok(_) => {
            // Success: remove backup if it exists
            if let Some(bak_path) = backup_path {
                fs::remove_file(bak_path)?;
            }
            Ok(())
        }
        Err(e) => {
            // Failure: restore from backup if it exists
            if let Some(bak_path) = backup_path {
                fs::copy(&bak_path, file_path)?;
                fs::remove_file(bak_path)?;
            }
            Err(e)
        }
    }
}

/// Main editing loop for the lines text editor
///
/// # Arguments
/// * `file_path` - Path to the file being edited
///
/// # Returns
/// * `io::Result<()>` - Success or error status of the editing session
///
/// # Behavior
/// 1. Displays file path and basic commands
/// 2. If file doesn't exist, creates it with timestamp header
/// 3. Shows last 10 lines of current file content
/// 4. Enters input loop where user can:
///    - Type text and press enter to append a line
///    - Enter 'q', 'quit', or 'exit' to close editor
/// 5. After each append, displays updated last 10 lines
///
/// # Errors
/// Returns error if:
/// - Cannot create/access the file
/// - Cannot read user input
/// - Cannot append to file
/// - Cannot display file contents
///
/// # Example
/// ```no_run
/// let path = Path::new("notes.txt");
/// editor_loop(&path)?;
/// ```
fn editor_loop(file_path: &Path) -> io::Result<()> {
    print!("\x1B[2J\x1B[1;1H");
    println!("lines text editor: Type 'q' to (q)uit");
    println!("file path -> {}", file_path.display());

    let stdin = io::stdin();
    let mut input = String::new();

    // Create file with header if it doesn't exist
    if !file_path.exists() {
        let header = get_header_text()?;
        append_line(file_path, &header)?;
        append_line(file_path, "")?; // blank line after header
    }

    // Display initial tail of file
    println!("Current file (last 10 lines) ->\n");
    if let Err(e) = memo_mode_display_file_tail(file_path, 10) {
        eprintln!("Error displaying file: {}", e);
    }

    loop {
        input.clear();
        print!("\n> "); // Add a prompt
        io::stdout().flush()?; // Ensure prompt is displayed

        if let Err(e) = stdin.read_line(&mut input) {
            eprintln!("Error reading input: {}", e);
            continue;
        }

        let trimmed = input.trim();

        if trimmed == "q" || trimmed == "quit" || trimmed == "exit" || trimmed == "exit()" {
            println!("Exiting editor...");
            break;
        }

        // Clear screen
        print!("\x1B[2J\x1B[1;1H");

        // Append the line with temporary backup protection
        if let Err(e) = append_line(file_path, trimmed) {
            eprintln!("Error writing to file: {}", e);
            continue;
        }

        // Display the tail of the file after append
        println!("\nLast 10 lines of file ->");
        if let Err(e) = memo_mode_display_file_tail(file_path, 10) {
            eprintln!("Error displaying file: {}", e);
        }
    }

    Ok(())
}

/// Gets or creates the default file path for the line editor.
/// If a custom filename is provided, appends the date to it.
///
/// # Arguments
/// * `custom_name` - Optional custom filename to use as prefix
///
/// # Returns
/// - For default: `{home}/Documents/lines_editor/yyyy_mm_dd.txt`
/// - For custom: `{home}/Documents/lines_editor/custom_name_yyyy_mm_dd.txt`
fn get_default_filepath(custom_name: Option<&str>) -> io::Result<PathBuf> {
    // Try to get home directory from environment variables
    let home = env::var("HOME")
        .or_else(|_| env::var("USERPROFILE"))
        .map_err(|e| {
            io::Error::new(
                io::ErrorKind::NotFound,
                format!("Could not find home directory: {}", e),
            )
        })?;

    // Build the base directory path
    let mut base_path = PathBuf::from(home);
    base_path.push("Documents");
    base_path.push("lines_editor");

    // Create all directories in the path if they don't exist
    fs::create_dir_all(&base_path)?;

    // Get timestamp for filename
    let timestamp = get_timestamp()?;

    // Create filename based on whether custom_name is provided
    let filename = match custom_name {
        Some(name) => format!("{}_{}.txt", name, timestamp),
        None => format!("{}.txt", timestamp),
    };

    // Join the base path with the filename
    Ok(base_path.join(filename))
}

/// Represents supported file managers and their launch commands
#[derive(Debug)]
enum FileManager {
    Nautilus,
    Dolphin,
    Thunar,
    Explorer,
    Finder,
}

impl FileManager {
    /// Converts the FileManager enum to its launch command string
    fn get_command(&self) -> &str {
        match self {
            FileManager::Nautilus => "nautilus",
            FileManager::Dolphin => "dolphin",
            FileManager::Thunar => "thunar",
            FileManager::Explorer => "explorer",
            FileManager::Finder => "open",
        }
    }
}

/// Detects the operating system and returns appropriate default file manager
/// Detects and returns the default file manager for the current operating system
///
/// # Returns
/// - `Ok(FileManager)` - Enum variant matching the system's default file manager
/// - `Err(io::Error)` - If operating system is unsupported
///
/// # Platform-Specific Behavior
/// ## Linux
/// - GNOME: Returns Nautilus
/// - KDE: Returns Dolphin
/// - XFCE: Returns Thunar
/// - Default/Unknown: Falls back to Nautilus
///
/// ## Windows
/// - Returns Explorer
///
/// ## macOS
/// - Returns Finder
///
/// # Environment Variables Used
/// - `XDG_CURRENT_DESKTOP`: Used on Linux to detect desktop environment
///
/// # Errors
/// Returns error if:
/// - Operating system is not Linux, Windows, or macOS
/// - Unable to determine desktop environment on Linux
///
/// # Usage Example
/// ```no_run
/// let file_manager = get_default_file_manager()?;
/// let command = file_manager.get_command();
/// // Use command to open files/directories
/// ```
///
fn get_default_file_manager() -> io::Result<FileManager> {
    let os = env::consts::OS;
    match os {
        "linux" => {
            // Check for common Linux desktop environments
            if let Ok(desktop) = env::var("XDG_CURRENT_DESKTOP") {
                match desktop.to_uppercase().as_str() {
                    "GNOME" => Ok(FileManager::Nautilus),
                    "KDE" => Ok(FileManager::Dolphin),
                    "XFCE" => Ok(FileManager::Thunar),
                    _ => Ok(FileManager::Nautilus), // Default to Nautilus
                }
            } else {
                Ok(FileManager::Nautilus)
            }
        }
        "windows" => Ok(FileManager::Explorer),
        "macos" => Ok(FileManager::Finder),
        _ => Err(io::Error::new(
            io::ErrorKind::Unsupported,
            format!("Unsupported operating system: {}", os),
        )),
    }
}

/// Opens the specified directory in the system's file manager
///
/// # Arguments
/// * `directory` - Path to the directory to open
/// * `file_manager` - Optional specific file manager to use
///
/// # Returns
/// * `io::Result<()>` - Success or error opening the file manager
fn memo_mode_open_in_file_manager(
    directory: &Path,
    file_manager: Option<FileManager>,
) -> io::Result<()> {
    // Ensure the directory exists
    if !directory.exists() {
        return Err(io::Error::new(
            io::ErrorKind::NotFound,
            "Directory does not exist",
        ));
    }

    let fm = match file_manager {
        Some(fm) => fm,
        None => get_default_file_manager()?,
    };

    // Prepare the command and arguments
    let command = fm.get_command();
    let dir_str = directory.to_string_lossy();

    // Execute the file manager command
    match std::process::Command::new(command).arg(&*dir_str).spawn() {
        Ok(_) => {
            println!("Opened {} in {:?}", dir_str, fm);
            Ok(())
        }
        Err(e) => Err(io::Error::new(
            io::ErrorKind::Other,
            format!("Failed to open file manager: {}", e),
        )),
    }
}

/// Reads forward a specified number of UTF-8 characters from a file
///
/// # Purpose
/// Reads characters (not bytes) from a file starting at a given byte offset.
/// Handles UTF-8 properly, ensuring we don't split multi-byte characters.
/// This is the core reading function for building window content.
///
/// # Arguments
/// * `file_path` - Absolute path to file to read from
/// * `start_byte` - Byte offset in file to start reading from
/// * `char_count` - Number of UTF-8 characters to read
/// * `output_buffer` - Pre-allocated buffer to write characters into
///
/// # Returns
/// * `Ok((bytes_read, chars_read))` - Number of bytes and characters actually read
/// * `Err(io::Error)` - Read failed
///
/// # Errors
/// - File not found
/// - Invalid byte offset (past end of file)
/// - Read permissions denied
/// - Invalid UTF-8 sequence in file
///
/// # Edge Cases
/// - Returns fewer characters if end of file reached
/// - Handles multi-byte UTF-8 characters correctly
/// - Returns (0, 0) if start_byte is at or past EOF
fn read_forward_chars(
    file_path: &Path,
    start_byte: u64,
    char_count: usize,
    output_buffer: &mut [u8],
) -> io::Result<(usize, usize)> {
    // Defensive: Verify absolute path
    if !file_path.is_absolute() {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "File path must be absolute",
        ));
    }

    // Defensive: Verify file exists
    if !file_path.exists() {
        return Err(io::Error::new(
            io::ErrorKind::NotFound,
            format!("File not found: {:?}", file_path),
        ));
    }

    // Defensive: Check buffer has space
    if output_buffer.is_empty() {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "Output buffer has zero size",
        ));
    }

    // Open file for reading
    let mut file = File::open(file_path)?;

    // Seek to start position
    use std::io::Seek;
    use std::io::SeekFrom;
    file.seek(SeekFrom::Start(start_byte))?;

    let mut bytes_read: usize = 0;
    let mut chars_found: usize = 0;
    let mut temp_buffer = [0u8; 4]; // Max UTF-8 char is 4 bytes

    // Read characters one by one
    const MAX_ITERATIONS: usize = 100_000; // Defensive: prevent infinite loop
    let mut iterations = 0;

    while chars_found < char_count && iterations < MAX_ITERATIONS {
        iterations += 1;

        // Read first byte of potential UTF-8 character
        let mut first_byte = [0u8; 1];
        match file.read(&mut first_byte) {
            Ok(0) => break, // End of file
            Ok(_) => {}
            Err(e) => return Err(e),
        }

        // Determine UTF-8 character length from first byte
        let char_len = if first_byte[0] & 0b1000_0000 == 0 {
            1 // ASCII (0xxxxxxx)
        } else if first_byte[0] & 0b1110_0000 == 0b1100_0000 {
            2 // 2-byte char (110xxxxx)
        } else if first_byte[0] & 0b1111_0000 == 0b1110_0000 {
            3 // 3-byte char (1110xxxx)
        } else if first_byte[0] & 0b1111_1000 == 0b1111_0000 {
            4 // 4-byte char (11110xxx)
        } else {
            // Invalid UTF-8 first byte
            return Err(io::Error::new(
                io::ErrorKind::InvalidData,
                format!(
                    "Invalid UTF-8 sequence at byte {}",
                    start_byte + bytes_read as u64
                ),
            ));
        };

        // Check if character will fit in output buffer
        if bytes_read + char_len > output_buffer.len() {
            break; // Buffer full, return what we have
        }

        // Read rest of multi-byte character
        temp_buffer[0] = first_byte[0];
        if char_len > 1 {
            file.read_exact(&mut temp_buffer[1..char_len])?;
        }

        // Validate UTF-8 continuation bytes
        for i in 1..char_len {
            if temp_buffer[i] & 0b1100_0000 != 0b1000_0000 {
                return Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    format!(
                        "Invalid UTF-8 continuation byte at position {}",
                        start_byte + bytes_read as u64 + i as u64
                    ),
                ));
            }
        }

        // Copy character to output buffer
        output_buffer[bytes_read..bytes_read + char_len].copy_from_slice(&temp_buffer[..char_len]);

        bytes_read += char_len;
        chars_found += 1;
    }

    // Defensive: Check for runaway loop
    if iterations >= MAX_ITERATIONS {
        return Err(io::Error::new(
            io::ErrorKind::Other,
            "Maximum iteration limit reached in read_forward_chars",
        ));
    }

    Ok((bytes_read, chars_found))
}

use std::io::Read;

#[cfg(test)]
mod window_map_update_tests {
    use super::*;

    /// Test that update_window_map_during_text_placement correctly maps ASCII text
    #[test]
    fn test_map_update_ascii() {
        let mut window_map = WindowMap::new();
        let text = b"Hello";
        let result = update_window_map_during_text_placement(
            &mut window_map,
            0,   // row 0
            5,   // starting at column 5 (after line number)
            100, // file byte position 100
            text,
            text.len(),
        );

        assert!(result.is_ok());

        // Verify each character is mapped correctly
        for i in 0..5 {
            let pos = window_map.get_file_position(0, 5 + i);
            assert!(pos.is_ok());
            let file_pos = pos.unwrap();
            assert!(file_pos.is_some());
            assert_eq!(file_pos.unwrap().byte_offset, 100 + i as u64);
        }
    }

    /// Test that update_window_map_during_text_placement handles UTF-8 correctly
    #[test]
    fn test_map_update_utf8() {
        let mut window_map = WindowMap::new();
        let text = "café".as_bytes(); // 'é' is 2 bytes in UTF-8

        let result = update_window_map_during_text_placement(
            &mut window_map,
            1,   // row 1
            10,  // starting at column 10
            200, // file byte position 200
            text,
            text.len(),
        );

        assert!(result.is_ok());

        // Check mappings:
        // 'c' at col 10 -> byte 200
        let pos = window_map.get_file_position(1, 10).unwrap().unwrap();
        assert_eq!(pos.byte_offset, 200);

        // 'a' at col 11 -> byte 201
        let pos = window_map.get_file_position(1, 11).unwrap().unwrap();
        assert_eq!(pos.byte_offset, 201);

        // 'f' at col 12 -> byte 202
        let pos = window_map.get_file_position(1, 12).unwrap().unwrap();
        assert_eq!(pos.byte_offset, 202);

        // 'é' at col 13 -> byte 203 (note: é takes 2 bytes but 1 display column)
        let pos = window_map.get_file_position(1, 13).unwrap().unwrap();
        assert_eq!(pos.byte_offset, 203);
    }

    /// Test that update_window_map_during_text_placement handles tabs correctly
    #[test]
    fn test_map_update_with_tab() {
        let mut window_map = WindowMap::new();
        let text = b"A\tB"; // Tab between A and B

        let result = update_window_map_during_text_placement(
            &mut window_map,
            2,   // row 2
            0,   // starting at column 0
            300, // file byte position 300
            text,
            text.len(),
        );

        assert!(result.is_ok());

        // 'A' at col 0 -> byte 300
        let pos = window_map.get_file_position(2, 0).unwrap().unwrap();
        assert_eq!(pos.byte_offset, 300);

        // Tab spans cols 1-3 (assuming TAB_WIDTH=4), all map to byte 301
        for col in 1..4 {
            let pos = window_map.get_file_position(2, col).unwrap().unwrap();
            assert_eq!(
                pos.byte_offset, 301,
                "Tab column {} should map to byte 301",
                col
            );
        }

        // 'B' at col 4 -> byte 302
        let pos = window_map.get_file_position(2, 4).unwrap().unwrap();
        assert_eq!(pos.byte_offset, 302);
    }

    /// Test bounds checking in update_window_map_during_text_placement
    #[test]
    fn test_map_update_bounds_check() {
        let mut window_map = WindowMap::new();
        let text = b"Test";

        // Test row out of bounds
        let result = update_window_map_during_text_placement(
            &mut window_map,
            MAX_ROWS + 1, // Invalid row
            0,
            0,
            text,
            text.len(),
        );
        assert!(result.is_err());

        // Test column out of bounds
        let result = update_window_map_during_text_placement(
            &mut window_map,
            0,
            MAX_COLS + 1, // Invalid column
            0,
            text,
            text.len(),
        );
        assert!(result.is_err());
    }

    // /// Integration test: build_window populates WindowMap correctly
    // #[test]
    // fn test_build_window_creates_map() {
    //     // Create test file
    //     let test_dir = Path::new("/tmp/lines_test");
    //     fs::create_dir_all(test_dir).expect("Failed to create test directory");
    //     let test_path = test_dir.join("map_test.txt");
    //     fs::write(&test_path, "Line 1\nLine 2\n").expect("Failed to write test file");

    //     // Build window
    //     let mut state = EditorState::new();
    //     let result = build_window(&mut state, &test_path);
    //     assert!(result.is_ok());

    //     // After build_window, the map should be populated
    //     // Line number "    1 " takes columns 0-4
    //     // "Line 1" starts at column 5

    //     // Check that 'L' of "Line 1" maps to byte 0 of file
    //     let pos = state.window_map.get_file_position(0, 5);
    //     assert!(pos.is_ok());
    //     let file_pos = pos.unwrap();
    //     assert!(file_pos.is_some());
    //     assert_eq!(
    //         file_pos.unwrap().byte_offset,
    //         0,
    //         "First 'L' should be at byte 0"
    //     );

    //     // Clean up
    //     fs::remove_file(test_path).ok();
    // }
}

// TODO how can this be tested?
/// Updates WindowMap tracking which file position corresponds to each display cell
///
/// # Purpose
/// Called during window building to record the mapping from each terminal cell
/// to its corresponding byte position in the file. This enables cursor-to-file
/// position translation for editing operations.
///
/// # Important
/// Correctly handles double-width characters (CJK) by mapping both display columns
/// to the same file position. This ensures cursor navigation works properly with
/// East Asian text.
///
/// # Arguments
/// * `window_map` - The WindowMap to update
/// * `display_row` - Current row being displayed (0-based)
/// * `display_col_start` - Starting column for this text (after line number)
/// * `file_byte_position` - Byte position in file where this text starts
/// * `text_bytes` - The actual bytes being displayed
/// * `text_length` - Number of bytes to map
///
/// # Returns
/// * `Ok(columns_used)` - Number of display columns consumed
/// * `Err(io::Error)` - If indices are out of bounds or UTF-8 is invalid
fn update_window_map_during_text_placement(
    window_map: &mut WindowMap,
    display_row: usize,
    display_col_start: usize,
    file_byte_position: u64,
    text_bytes: &[u8],
    text_length: usize,
) -> io::Result<usize> {
    // Defensive: Validate row bounds
    if display_row >= MAX_ROWS {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            format!("Display row {} exceeds maximum {}", display_row, MAX_ROWS),
        ));
    }

    // Defensive: Validate column start
    if display_col_start >= MAX_COLS {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            format!(
                "Display column start {} exceeds maximum {}",
                display_col_start, MAX_COLS
            ),
        ));
    }

    // Defensive: Validate text_length doesn't exceed buffer
    if text_length > text_bytes.len() {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            format!(
                "Text length {} exceeds buffer size {}",
                text_length,
                text_bytes.len()
            ),
        ));
    }

    let mut current_col = display_col_start;
    let initial_col = display_col_start;
    let mut byte_index = 0usize;

    // Maximum iterations to prevent infinite loop
    const MAX_ITERATIONS: usize = 1000;
    let mut iterations = 0;

    while byte_index < text_length && current_col < MAX_COLS && iterations < MAX_ITERATIONS {
        iterations += 1;

        // Defensive: Additional bounds check
        if byte_index >= text_bytes.len() {
            return Err(io::Error::new(
                io::ErrorKind::InvalidData,
                "Byte index exceeded buffer during mapping",
            ));
        }

        let byte_value = text_bytes[byte_index];

        // Handle special characters
        if byte_value == b'\n' {
            // Newline shouldn't appear here (should be handled by caller)
            // But defensive programming: skip it
            byte_index += 1;
            continue;
        }

        if byte_value == b'\t' {
            // Tab character - spans multiple columns
            const TAB_WIDTH: usize = 4;
            let tab_stop = ((current_col / TAB_WIDTH) + 1) * TAB_WIDTH;
            let tab_span = tab_stop.saturating_sub(current_col).min(TAB_WIDTH);

            // Map all columns covered by the tab to the same file position
            for i in 0..tab_span {
                if current_col + i < MAX_COLS {
                    let file_pos = FilePosition {
                        byte_offset: file_byte_position + byte_index as u64,
                        line_number: 0, // Will be set by caller
                        byte_in_line: byte_index,
                    };
                    window_map.set_file_position(display_row, current_col + i, Some(file_pos))?;
                }
            }
            current_col += tab_span;
            byte_index += 1;
            continue;
        }

        // Determine UTF-8 character byte length
        let char_byte_length = if byte_value & 0b1000_0000 == 0 {
            1 // ASCII
        } else if byte_value & 0b1110_0000 == 0b1100_0000 {
            2 // 2-byte UTF-8
        } else if byte_value & 0b1111_0000 == 0b1110_0000 {
            3 // 3-byte UTF-8
        } else if byte_value & 0b1111_1000 == 0b1111_0000 {
            4 // 4-byte UTF-8
        } else {
            // Defensive: Invalid UTF-8 start byte or continuation byte - skip
            byte_index += 1;
            continue;
        };

        // Defensive: Ensure we don't read past buffer
        if byte_index + char_byte_length > text_length {
            break;
        }

        // Parse the actual character to determine display width
        let char_slice = &text_bytes[byte_index..byte_index + char_byte_length];

        // Defensive: Validate UTF-8 before parsing
        let current_char = match std::str::from_utf8(char_slice) {
            Ok(s) => {
                match s.chars().next() {
                    Some(c) => c,
                    None => {
                        // Should not happen with valid UTF-8
                        byte_index += char_byte_length;
                        continue;
                    }
                }
            }
            Err(_) => {
                // Invalid UTF-8 sequence, skip it
                byte_index += char_byte_length;
                continue;
            }
        };

        // Determine display width (1 or 2 columns)
        let calculate_display_width = if double_width::is_double_width(current_char) {
            2
        } else {
            1
        };

        // Create file position for this character
        let file_pos = FilePosition {
            byte_offset: file_byte_position + byte_index as u64,
            line_number: 0, // Will be set by caller with actual line number
            byte_in_line: byte_index,
        };

        // Map display cell(s) to file position
        // For double-width chars, BOTH columns map to the same file position
        for col_offset in 0..calculate_display_width {
            if current_col + col_offset < MAX_COLS {
                window_map.set_file_position(
                    display_row,
                    current_col + col_offset,
                    Some(file_pos),
                )?;
            }
        }

        // Advance by display width, not byte length
        current_col += calculate_display_width;
        byte_index += char_byte_length;
    }

    // Defensive: Check for runaway loop
    if iterations >= MAX_ITERATIONS {
        return Err(io::Error::new(
            io::ErrorKind::Other,
            "Maximum iterations exceeded in window map update",
        ));
    }

    // Return number of display columns actually used
    Ok(current_col.saturating_sub(initial_col))
}

/// Module for detecting double-width (full-width) UTF-8 characters in terminal display.
///
/// This module provides fast, reliable detection of characters that occupy two columns
/// in terminal display, primarily East Asian characters (CJK) and full-width variants.
///
/// # Implementation Notes
/// - Uses a pre-compiled lookup table for O(1) performance
/// - No third-party dependencies
/// - Memory-safe with no dynamic allocation
/// - Based on Unicode 15.0 East Asian Width property
pub mod double_width {

    /// Maximum number of double-width character ranges we support.
    /// Pre-allocated to avoid dynamic memory allocation per NASA Power of 10 rules.
    const MAX_RANGES: usize = 128;

    /// Compiled lookup table of Unicode ranges for double-width characters.
    /// Each tuple represents (start, end) of an inclusive range.
    ///
    /// # Source
    /// Based on Unicode East Asian Width property categories:
    /// - F (Fullwidth): Always double-width
    /// - W (Wide): Always double-width in East Asian contexts
    ///
    /// # Memory Layout
    /// Pre-allocated array avoids dynamic allocation.
    /// Unused slots are filled with (0, 0) which won't match valid characters.
    const DOUBLE_WIDTH_RANGES: [(u32, u32); MAX_RANGES] = [
        // CJK Symbols and Punctuation
        (0x3000, 0x303F),
        // Hiragana - FIXED: Added this missing range
        (0x3040, 0x309F),
        // Katakana - FIXED: Added this missing range
        (0x30A0, 0x30FF),
        // CJK Strokes
        (0x31C0, 0x31EF),
        // Katakana Phonetic Extensions
        (0x31F0, 0x31FF),
        // Enclosed CJK Letters and Months
        (0x3200, 0x32FF),
        // CJK Compatibility
        (0x3300, 0x33FF),
        // CJK Unified Ideographs Extension A
        (0x3400, 0x4DBF),
        // CJK Unified Ideographs (main block)
        (0x4E00, 0x9FFF),
        // Yi Syllables
        (0xA000, 0xA48F),
        // Yi Radicals
        (0xA490, 0xA4CF),
        // Hangul Jamo Extended-A
        (0xA960, 0xA97F),
        // Hangul Syllables
        (0xAC00, 0xD7AF),
        // CJK Compatibility Ideographs
        (0xF900, 0xFAFF),
        // Vertical Forms
        (0xFE10, 0xFE1F),
        // CJK Compatibility Forms
        (0xFE30, 0xFE4F),
        // Small Form Variants
        (0xFE50, 0xFE6F),
        // Halfwidth and Fullwidth Forms (fullwidth part)
        (0xFF01, 0xFF60),
        (0xFFE0, 0xFFE6),
        // Kana Supplement
        (0x1B000, 0x1B0FF),
        // Kana Extended-A
        (0x1B100, 0x1B12F),
        // Small Kana Extension
        (0x1B130, 0x1B16F),
        // CJK Unified Ideographs Extension B
        (0x20000, 0x2A6DF),
        // CJK Unified Ideographs Extension C
        (0x2A700, 0x2B73F),
        // CJK Unified Ideographs Extension D
        (0x2B740, 0x2B81F),
        // CJK Unified Ideographs Extension E
        (0x2B820, 0x2CEAF),
        // CJK Unified Ideographs Extension F
        (0x2CEB0, 0x2EBEF),
        // CJK Compatibility Ideographs Supplement
        (0x2F800, 0x2FA1F),
        // CJK Unified Ideographs Extension G
        (0x30000, 0x3134F),
        // Fill remaining slots with (0, 0) - won't match any valid character
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
        (0, 0),
    ];

    /// Determines if a UTF-8 character is double-width in terminal display.
    ///
    /// # Arguments
    /// * `c` - The character to check
    ///
    /// # Returns
    /// * `true` if the character occupies two columns in terminal display
    /// * `false` if the character occupies one column (or zero for combining marks)
    ///
    /// # Performance
    /// O(n) where n is the number of ranges (currently ~27), but with early exit
    /// optimization for ASCII characters which are the most common case.
    ///
    /// # Examples
    /// ```
    /// assert_eq!(is_double_width('A'), false);  // ASCII - single width
    /// assert_eq!(is_double_width('中'), true);  // Chinese - double width
    /// assert_eq!(is_double_width('あ'), true);  // Hiragana - double width
    /// assert_eq!(is_double_width('ア'), true);  // Katakana - double width
    /// assert_eq!(is_double_width('한'), true);  // Hangul - double width
    /// assert_eq!(is_double_width('Ａ'), true);  // Fullwidth Latin - double width
    /// ```
    ///
    /// # Edge Cases
    /// - Control characters: returns false
    /// - Combining marks: returns false (they don't advance cursor)
    /// - Emoji: most return false (emoji width is complex and font-dependent)
    /// - Invalid Unicode: returns false
    pub fn is_double_width(c: char) -> bool {
        let code_point = c as u32;

        // Fast path: ASCII characters are never double-width
        // This catches the most common case immediately
        if code_point < 0x80 {
            debug_assert!(code_point < 0x80, "ASCII range check failed");
            return false;
        }

        // Fast path: Characters below the first CJK block are mostly single-width
        // Exception: Some symbols in the 0x3000-0x303F range
        if code_point < 0x3000 {
            debug_assert!(code_point < 0x3000, "Pre-CJK range check failed");
            return false;
        }

        // Binary search through our sorted ranges
        // Loop counter for NASA Power of 10 rule #2
        let mut iterations = 0;
        const MAX_ITERATIONS: usize = 8; // log2(128) rounded up

        let mut left = 0;
        let mut right = MAX_RANGES;

        while left < right && iterations < MAX_ITERATIONS {
            iterations += 1;

            let mid = left + (right - left) / 2;
            let (range_start, range_end) = DOUBLE_WIDTH_RANGES[mid];

            // Skip empty slots (0, 0)
            if range_start == 0 && range_end == 0 {
                right = mid;
                continue;
            }

            if code_point < range_start {
                right = mid;
            } else if code_point > range_end {
                left = mid + 1;
            } else {
                // Found in range
                debug_assert!(
                    code_point >= range_start && code_point <= range_end,
                    "Character should be within found range"
                );
                return true;
            }
        }

        // Defensive assertion: we should have checked all relevant ranges
        debug_assert!(
            iterations <= MAX_ITERATIONS,
            "Binary search exceeded maximum iterations"
        );

        false
    }

    /// Calculates the display width of a string in terminal columns.
    ///
    /// # Arguments
    /// * `text` - The text to measure
    ///
    /// # Returns
    /// * `Option<usize>` - The width in terminal columns, or None if calculation fails
    ///
    /// # Examples
    /// ```
    /// assert_eq!(calculate_display_width("Hello"), Some(5));
    /// assert_eq!(calculate_display_width("你好"), Some(4)); // Two double-width characters
    /// assert_eq!(calculate_display_width("Hello世界"), Some(9)); // 5 + 2*2
    /// ```
    ///
    /// # Error Handling
    /// Returns `None` if:
    /// - The string contains invalid UTF-8 (shouldn't happen with Rust strings)
    /// - Integer overflow occurs (extremely long strings)
    pub fn calculate_display_width(text: &str) -> Option<usize> {
        let mut width = 0usize;
        let mut char_count = 0;
        const MAX_CHARS: usize = 1_000_000; // Upper bound per NASA rule #2

        for c in text.chars() {
            // Prevent infinite loops with character count limit
            if char_count >= MAX_CHARS {
                return None;
            }
            char_count += 1;

            // Add 2 for double-width, 1 for single-width
            let char_width = if is_double_width(c) { 2 } else { 1 };

            // Check for overflow before adding
            width = width.checked_add(char_width)?;
        }

        // Defensive assertion: result should be reasonable
        debug_assert!(
            width <= text.len() * 2,
            "Display width should not exceed twice the byte length"
        );

        Some(width)
    }
}

#[cfg(test)]
mod char_width_tests {
    use super::double_width::*;

    #[test]
    fn test_ascii_characters() {
        // All ASCII characters should be single-width
        for c in 0x20..0x7F {
            let ch = char::from_u32(c).expect("Valid ASCII character");
            assert_eq!(
                is_double_width(ch),
                false,
                "ASCII '{}' should be single-width",
                ch
            );
        }
    }

    #[test]
    fn test_cjk_ideographs() {
        // Common CJK characters should be double-width
        let test_chars = ['中', '文', '字', '日', '本', '語', '한', '글'];
        for &c in &test_chars {
            assert_eq!(
                is_double_width(c),
                true,
                "CJK '{}' should be double-width",
                c
            );
        }
    }

    #[test]
    fn test_hiragana_katakana() {
        // Hiragana
        assert_eq!(is_double_width('あ'), true);
        assert_eq!(is_double_width('い'), true);
        assert_eq!(is_double_width('う'), true);

        // Katakana
        assert_eq!(is_double_width('ア'), true);
        assert_eq!(is_double_width('イ'), true);
        assert_eq!(is_double_width('ウ'), true);
    }

    #[test]
    fn test_fullwidth_forms() {
        // Fullwidth Latin letters
        assert_eq!(is_double_width('Ａ'), true);
        assert_eq!(is_double_width('Ｂ'), true);
        assert_eq!(is_double_width('１'), true);
        assert_eq!(is_double_width('２'), true);
    }

    #[test]
    fn test_calculate_display_width() {
        assert_eq!(calculate_display_width("Hello"), Some(5));
        assert_eq!(calculate_display_width("你好"), Some(4));
        assert_eq!(calculate_display_width("Hello世界"), Some(9));
        assert_eq!(calculate_display_width(""), Some(0));
        assert_eq!(calculate_display_width("ＡＢＣ"), Some(6));
    }

    #[test]
    fn test_mixed_width_string() {
        let mixed = "Hello 世界 World";
        let expected = 5 + 1 + 2 + 2 + 1 + 5; // "Hello" + " " + "世界" + " " + "World"
        assert_eq!(calculate_display_width(mixed), Some(expected));
    }

    #[test]
    fn test_edge_cases() {
        // Control characters
        assert_eq!(is_double_width('\n'), false);
        assert_eq!(is_double_width('\t'), false);
        assert_eq!(is_double_width('\r'), false);

        // Space
        assert_eq!(is_double_width(' '), false);

        // Emoji (most are not double-width in our definition)
        assert_eq!(is_double_width('😀'), false);
    }
}

/// Diagnostic function to print contents of test files
fn print_test_file_contents(file_path: &Path) -> io::Result<()> {
    println!("=== File Contents: {} ===", file_path.display());
    let file = File::open(file_path)?;
    let reader = BufReader::new(file);

    for (index, line) in reader.lines().enumerate() {
        let line = line?;
        println!("{:4}: {}", index + 1, line);
    }

    // Get file metadata
    let metadata = std::fs::metadata(file_path)?;
    println!("\nFile size: {} bytes", metadata.len());

    Ok(())
}

// Modify the test to include more diagnostics
#[test]
fn test_build_windowmap_nowrap_basic() -> io::Result<()> {
    // Create test files
    let test_files = create_test_files_with_id("test_build_windowmap_nowrap_basic")?;
    let basic_file = &test_files[0]; // basic_short.txt

    // Print file contents for debugging
    print_test_file_contents(basic_file)?;

    // Create editor state
    let mut state = EditorState::new();
    state.line_count_at_top_of_window = 0;
    state.file_position_of_topline_start = 0;
    state.horizontal_line_char_offset = 0;

    // Debug: print file path and existence
    println!("Test file path: {:?}", basic_file);
    println!("File exists: {}", basic_file.exists());

    // Verify file is readable
    let file = File::open(basic_file)?;
    let reader = BufReader::new(file);
    let line_count = reader.lines().count();
    println!("Line count in file: {}", line_count);

    // Build window
    let result = build_windowmap_nowrap(&mut state, basic_file);

    // Debug: print detailed error if failed
    if let Err(ref e) = result {
        println!("Build window failed: {}", e);
    }

    assert!(result.is_ok(), "Should build window successfully");

    let lines_processed = result.unwrap();
    println!("Lines processed: {}", lines_processed);

    // Debug: print buffer contents
    for i in 0..5 {
        if state.display_buffer_lengths[i] > 0 {
            let content = &state.display_buffers[i][..state.display_buffer_lengths[i]];
            println!("Row {}: {:?}", i, String::from_utf8_lossy(content));
        }
    }

    assert!(lines_processed > 0, "Should process at least one line");

    // Verify first line has content
    assert!(
        state.display_buffer_lengths[0] > 0,
        "First row should have content"
    );

    // Verify line number "1 " appears at start
    let first_row = &state.display_buffers[0];
    assert_eq!(first_row[0], b'1', "Should start with line number 1");
    assert_eq!(first_row[1], b' ', "Should have space after line number");

    // Verify WindowMap has been populated
    let map_entry = state.window_map.get_file_position(0, 2).unwrap();
    assert!(map_entry.is_some(), "Character position should be mapped");

    Ok(())
}

/// Prints the expected window output for a test file
///
/// # Purpose
/// Helper function to visualize what build_windowmap_nowrap SHOULD produce
/// for a given test file. This helps us verify our implementation.
///
/// # Arguments
/// * `test_file` - Path to test file
/// * `start_line` - Line number to start display from (0-indexed)
/// * `horizontal_offset` - Character offset for NoWrap mode
///
/// # Example Output
/// Shows what should appear in each display buffer row:
/// ```
/// Row 0: "1 Line 1: Hello, world!"
/// Row 1: "2 Line 2: This is a test."
/// ```
fn print_expected_window(
    test_file: &Path,
    start_line: usize,
    horizontal_offset: usize,
) -> io::Result<()> {
    println!(
        "\nExpected window for: {:?}",
        test_file.file_name().unwrap_or_default()
    );
    println!(
        "Start line: {}, Horizontal offset: {}",
        start_line, horizontal_offset
    );

    let file = File::open(test_file)?;
    let reader = BufReader::new(file);
    let mut current_line = 0;
    let mut display_row = 0;
    const MAX_DISPLAY_ROWS: usize = 21;
    const MAX_DISPLAY_COLS: usize = 77; // 80 - 3 for UI elements

    for line in reader.lines() {
        let line = line?;

        // Skip lines before our window start
        if current_line < start_line {
            current_line += 1;
            continue;
        }

        // Stop if we've filled the display
        if display_row >= MAX_DISPLAY_ROWS {
            break;
        }

        // Format line number (starting from 1 for display)
        let line_num_str = format!("{} ", current_line + 1);
        let line_num_width = line_num_str.len();

        // Calculate available space for text after line number
        let available_width = MAX_DISPLAY_COLS.saturating_sub(line_num_width);

        // Get the portion of line to display (respecting horizontal offset)
        let line_chars: Vec<char> = line.chars().collect();
        let visible_text = if horizontal_offset < line_chars.len() {
            let end_idx = (horizontal_offset + available_width).min(line_chars.len());
            line_chars[horizontal_offset..end_idx]
                .iter()
                .collect::<String>()
        } else {
            String::new() // Horizontal offset past end of line
        };

        println!(
            "Row {:2}: \"{}{}\"",
            display_row, line_num_str, visible_text
        );

        display_row += 1;
        current_line += 1;
    }

    // Fill remaining rows with empty
    while display_row < MAX_DISPLAY_ROWS {
        println!("Row {:2}: (empty)", display_row);
        display_row += 1;
    }

    Ok(())
}

#[cfg(test)]
mod test_file_tests {
    use super::*;

    #[test]
    fn test_create_test_files() {
        let result = create_test_files_with_id("test_create_test_files");
        assert!(result.is_ok(), "Should create test files successfully");

        let files = result.unwrap();
        assert_eq!(files.len(), 4, "Should create 4 test files");

        // Verify each file exists and has content
        for path in &files {
            assert!(path.exists(), "File {:?} should exist", path);

            let metadata = std::fs::metadata(path).unwrap();
            assert!(metadata.len() > 0, "File {:?} should have content", path);
        }
    }

    #[test]
    fn test_basic_short_content() {
        let files = create_test_files_with_id("test_basic_short_content").unwrap();
        let basic_short = &files[0];

        // Read first line and verify it's short
        let file = File::open(basic_short).unwrap();
        let mut reader = BufReader::new(file);
        let mut first_line = String::new();
        reader.read_line(&mut first_line).unwrap();

        // Remove newline
        let trimmed = first_line.trim_end();
        assert!(trimmed.len() < 40, "First line should be under 40 chars");
        assert_eq!(trimmed, "Line 1: Hello, world!");
    }
}

/// Builds the window-to-file mapping for NoWrap mode
///
/// # Purpose
/// Reads file content and populates display buffers with proper line numbers
/// and text, while maintaining a complete mapping of which file byte each
/// terminal cell corresponds to.
///
/// # NoWrap Mode Behavior
/// - Each file line maps to exactly one display row (no wrapping)
/// - Lines longer than terminal width are truncated at display edge
/// - Horizontal scrolling is controlled by state.horizontal_line_char_offset
/// - Empty file lines still consume a display row
///
/// # Arguments
/// * `state` - Editor state containing buffers and window position info
/// * `file_path` - Absolute path to the file being displayed
///
/// # Returns
/// * `Ok(lines_processed)` - Number of file lines successfully processed
/// * `Err(io::Error)` - If file operations fail or invalid UTF-8 encountered
///
/// # State Modified
/// - `state.display_buffers` - Filled with line numbers and visible text
/// - `state.display_buffer_lengths` - Set to actual bytes used per row
/// - `state.window_map` - Updated with file position for each display cell
///
/// # Defensive Programming
/// - Validates file exists before reading
/// - Bounds checks all buffer accesses
/// - Handles invalid UTF-8 gracefully
/// - Limits iteration counts to prevent infinite loops
///
/// # Example
/// For a file starting "Hello\nWorld\n" with window at line 1:
/// - Row 0: "1 Hello"
/// - Row 1: "2 World"
/// WindowMap will map each character to its file byte position.
pub fn build_windowmap_nowrap(state: &mut EditorState, file_path: &Path) -> io::Result<usize> {
    // Defensive: Validate inputs
    if !file_path.is_absolute() {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "File path must be absolute",
        ));
    }

    if !file_path.exists() {
        return Err(io::Error::new(
            io::ErrorKind::NotFound,
            format!("File not found: {:?}", file_path),
        ));
    }

    // Assertion: State should have valid dimensions
    debug_assert!(state.effective_rows > 0, "Effective rows must be positive");
    debug_assert!(state.effective_cols > 0, "Effective cols must be positive");

    // Clear existing buffers and map before building
    state.clear_display_buffers();
    state.window_map.clear();

    // Open file for reading
    let mut file = File::open(file_path)?;

    // Seek to window start position
    use std::io::{Seek, SeekFrom};
    file.seek(SeekFrom::Start(state.file_position_of_topline_start))?;

    // Pre-allocate read buffer for one line at a time
    // Max line we'll try to read (defensive limit)
    const MAX_LINE_BYTES: usize = 4096;
    let mut line_buffer = [0u8; MAX_LINE_BYTES];

    let mut current_display_row = 0usize;
    let mut current_line_number = state.line_count_at_top_of_window;
    let mut lines_processed = 0usize;
    let mut file_byte_position = state.file_position_of_topline_start;

    // Defensive: Limit iterations to prevent infinite loops
    const MAX_ITERATIONS: usize = 1000;
    let mut iteration_count = 0;

    // Process lines until display is full or file ends
    while current_display_row < state.effective_rows && iteration_count < MAX_ITERATIONS {
        iteration_count += 1;

        // Assertion: We should not exceed our display buffer count
        debug_assert!(current_display_row < 45, "Display row exceeds maximum");

        // Read one line from file (up to newline or MAX_LINE_BYTES)
        let (line_bytes, line_length, found_newline) =
            read_single_line(&mut file, &mut line_buffer)?;

        // Check for end of file
        if line_length == 0 && !found_newline {
            break; // End of file reached
        }

        // Write line number to display buffer
        let line_number_display = current_line_number + 1; // Convert 0-indexed to 1-indexed
        let line_num_bytes_written =
            state.write_line_number(current_display_row, line_number_display)?;

        // Calculate how many columns remain after line number
        let remaining_cols = state.effective_cols.saturating_sub(line_num_bytes_written);

        // Process the line text with horizontal offset
        let text_bytes_written = process_line_with_offset(
            state,
            current_display_row,
            line_num_bytes_written, // Column position after line number
            &line_bytes[..line_length],
            state.horizontal_line_char_offset,
            remaining_cols,
            file_byte_position,
        )?;

        // Update total buffer length for this row
        state.display_buffer_lengths[current_display_row] =
            line_num_bytes_written + text_bytes_written;

        // Advance to next line
        current_display_row += 1;
        current_line_number += 1;
        lines_processed += 1;

        // Update file position for next line
        file_byte_position += line_length as u64;
        if found_newline {
            file_byte_position += 1; // Account for newline character
        }
    }

    // Defensive: Check we didn't hit iteration limit
    if iteration_count >= MAX_ITERATIONS {
        return Err(io::Error::new(
            io::ErrorKind::Other,
            "Maximum iterations exceeded in build_windowmap_nowrap",
        ));
    }

    // Assertion: Verify our line count makes sense
    debug_assert!(
        lines_processed <= state.effective_rows,
        "Processed more lines than display rows available"
    );

    Ok(lines_processed)
}

/// Reads a single line from file into buffer
///
/// # Purpose
/// Reads bytes from current file position until newline or buffer limit.
/// Does NOT include the newline character in the returned bytes.
///
/// # Arguments
/// * `file` - Open file handle positioned at start of line
/// * `buffer` - Pre-allocated buffer to read into
///
/// # Returns
/// * `Ok((buffer, bytes_read, found_newline))` - The buffer, bytes read, and whether newline was found
/// * `Err(io::Error)` - If read operation fails
///
/// # Defensive Notes
/// - Stops at newline character (0x0A)
/// - Stops if buffer is full
/// - Returns found_newline flag to distinguish EOF from empty line
fn read_single_line<'a>(
    file: &'a mut File,
    buffer: &'a mut [u8; 4096],
) -> io::Result<(&'a [u8; 4096], usize, bool)> {
    use std::io::Read;

    let mut bytes_read = 0usize;
    let mut found_newline = false;
    let mut single_byte = [0u8; 1];

    // Defensive: Limit iterations
    const MAX_ITERATIONS: usize = 4096;
    let mut iterations = 0;

    while bytes_read < buffer.len() && iterations < MAX_ITERATIONS {
        iterations += 1;

        // Diagnostic: print bytes read so far
        if iterations % 10 == 0 {
            println!("Iterations: {}, Bytes read: {}", iterations, bytes_read);
        }

        // Read one byte at a time (inefficient but simple for MVP)
        match file.read(&mut single_byte)? {
            0 => break, // EOF reached
            1 => {
                if single_byte[0] == b'\n' {
                    found_newline = true;
                    break; // Don't include newline in buffer
                }

                buffer[bytes_read] = single_byte[0];
                bytes_read += 1;
            }
            _ => {
                // Should not happen with single byte read
                return Err(io::Error::new(
                    io::ErrorKind::Other,
                    "Unexpected read result",
                ));
            }
        }
    }
    println!(
        "Final bytes read: {}, Found newline: {}",
        bytes_read, found_newline
    );

    // Assertion: We should have stayed within bounds
    debug_assert!(bytes_read <= buffer.len(), "Read exceeded buffer size");
    debug_assert!(
        iterations <= MAX_ITERATIONS,
        "Too many iterations in line read"
    );

    Ok((buffer, bytes_read, found_newline))
}

/// Processes a line with horizontal offset and writes visible portion to display
///
/// # Purpose
/// Takes a line's bytes, skips horizontal_offset characters, then writes
/// the visible portion to the display buffer while updating WindowMap.
///
/// # Arguments
/// * `state` - Editor state for buffers and map
/// * `row` - Display row index
/// * `col_start` - Starting column (after line number)
/// * `line_bytes` - The complete line text as bytes
/// * `horizontal_offset` - Number of characters to skip from line start
/// * `max_cols` - Maximum columns available for text
/// * `file_line_start` - Byte position where this line starts in file
///
/// # Returns
/// * `Ok(bytes_written)` - Number of bytes written to display buffer
/// * `Err(io::Error)` - If UTF-8 parsing fails or buffer access fails
///
/// # UTF-8 Handling
/// - Properly skips complete characters, not bytes
/// - Handles multi-byte UTF-8 sequences correctly
/// - Maps double-width characters to two display columns
fn process_line_with_offset(
    state: &mut EditorState,
    row: usize,
    col_start: usize,
    line_bytes: &[u8],
    horizontal_offset: usize,
    max_cols: usize,
    file_line_start: u64,
) -> io::Result<usize> {
    // Defensive: Validate row index
    if row >= 45 {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            format!("Row {} exceeds maximum display rows", row),
        ));
    }

    // First pass: Skip horizontal_offset characters (not bytes!)
    let mut byte_index = 0usize;
    let mut chars_skipped = 0usize;

    // Defensive: Limit iterations
    const MAX_ITERATIONS: usize = 10000;
    let mut iterations = 0;

    while byte_index < line_bytes.len()
        && chars_skipped < horizontal_offset
        && iterations < MAX_ITERATIONS
    {
        iterations += 1;

        // Determine character byte length from first byte
        let byte_val = line_bytes[byte_index];
        let char_len = if byte_val & 0b1000_0000 == 0 {
            1 // ASCII
        } else if byte_val & 0b1110_0000 == 0b1100_0000 {
            2 // 2-byte UTF-8
        } else if byte_val & 0b1111_0000 == 0b1110_0000 {
            3 // 3-byte UTF-8
        } else if byte_val & 0b1111_1000 == 0b1111_0000 {
            4 // 4-byte UTF-8
        } else {
            // Invalid UTF-8 or continuation byte - skip single byte
            1
        };

        // Skip this character
        byte_index = (byte_index + char_len).min(line_bytes.len());
        chars_skipped += 1;
    }

    // Assertion: We should have skipped the right number of characters
    debug_assert!(
        chars_skipped <= horizontal_offset,
        "Skipped more characters than requested"
    );

    // Second pass: Write visible characters to display buffer
    let mut display_col = col_start;
    let mut bytes_written = 0usize;
    iterations = 0; // Reset iteration counter

    while byte_index < line_bytes.len()
        && display_col < col_start + max_cols
        && iterations < MAX_ITERATIONS
    {
        iterations += 1;

        // Parse next UTF-8 character
        let byte_val = line_bytes[byte_index];
        let char_len = if byte_val & 0b1000_0000 == 0 {
            1 // ASCII
        } else if byte_val & 0b1110_0000 == 0b1100_0000 {
            2 // 2-byte UTF-8
        } else if byte_val & 0b1111_0000 == 0b1110_0000 {
            3 // 3-byte UTF-8
        } else if byte_val & 0b1111_1000 == 0b1111_0000 {
            4 // 4-byte UTF-8
        } else {
            // Skip invalid bytes
            byte_index += 1;
            continue;
        };

        // Check if complete character is available
        if byte_index + char_len > line_bytes.len() {
            break; // Incomplete character at end
        }

        // Get the character bytes
        let char_bytes = &line_bytes[byte_index..byte_index + char_len];

        // Check how many display columns this character needs
        let display_width = if char_len == 1 {
            1 // ASCII is always single-width
        } else {
            // Parse character to check if double-width
            match std::str::from_utf8(char_bytes) {
                Ok(s) => {
                    if let Some(ch) = s.chars().next() {
                        if double_width::is_double_width(ch) {
                            2
                        } else {
                            1
                        }
                    } else {
                        1 // Default to single-width
                    }
                }
                Err(_) => 1, // Invalid UTF-8, treat as single-width
            }
        };

        // Check if character fits in remaining space
        if display_col + display_width > col_start + max_cols {
            break; // Character would exceed display width
        }

        // Write character to display buffer
        if col_start + bytes_written + char_len <= 182 {
            // Copy bytes to display buffer
            for i in 0..char_len {
                state.display_buffers[row][col_start + bytes_written + i] = char_bytes[i];
            }

            // Update WindowMap for this character position
            let file_pos = FilePosition {
                byte_offset: file_line_start + byte_index as u64,
                line_number: state.line_count_at_top_of_window,
                byte_in_line: byte_index,
            };

            // Map all display columns this character occupies
            for i in 0..display_width {
                state
                    .window_map
                    .set_file_position(row, display_col + i, Some(file_pos))?;
            }

            bytes_written += char_len;
            display_col += display_width;
        } else {
            break; // Buffer full
        }

        byte_index += char_len;
    }

    // Defensive: Check iteration limit
    if iterations >= MAX_ITERATIONS {
        return Err(io::Error::new(
            io::ErrorKind::Other,
            "Maximum iterations exceeded in line processing",
        ));
    }

    // Assertion: Verify we stayed within bounds
    debug_assert!(bytes_written <= 182, "Wrote more bytes than buffer size");

    Ok(bytes_written)
}

/// Renders the current window content to a writer (for testability)
///
/// # Purpose
/// Prints the pre-populated display buffers to the provided writer.
/// This allows both terminal output and test capture.
///
/// # Arguments
/// * `state` - Current editor state with display buffers
/// * `writer` - Where to write the output (stdout or test buffer)
///
/// # Returns
/// * `io::Result<()>` - Success or error in displaying content
fn display_window_to_writer<W: Write>(state: &EditorState, writer: &mut W) -> io::Result<()> {
    // Clear screen escape codes (only for actual terminal)
    // Don't include in test output as it makes verification harder

    // Render each row in the display buffer
    for row in 0..state.effective_rows {
        // Only render rows that have content
        if state.display_buffer_lengths[row] > 0 {
            let row_content = &state.display_buffers[row][..state.display_buffer_lengths[row]];

            // Safely convert to UTF-8 string
            match std::str::from_utf8(row_content) {
                Ok(row_str) => writeln!(writer, "{}", row_str)?,
                Err(_) => {
                    // Fallback for invalid UTF-8: show replacement character
                    writeln!(writer, "�")?;
                }
            }
        } else {
            // Empty rows, just print newline to maintain vertical spacing
            writeln!(writer)?;
        }
    }

    writer.flush()?;
    Ok(())
}

/// Renders the current window content to the terminal
///
/// # Purpose
/// Prints the pre-populated display buffers to stdout with screen clearing.
///
/// # Arguments
/// * `state` - Current editor state with display buffers
///
/// # Returns
/// * `io::Result<()>` - Success or error in displaying content
fn display_window(state: &EditorState) -> io::Result<()> {
    // Clear screen before rendering
    print!("\x1B[2J\x1B[H");
    io::stdout().flush()?;

    // Use the writer version with stdout
    display_window_to_writer(state, &mut io::stdout())
}

/// Fixed integration tests for display_window
#[cfg(test)]
mod display_window_tests1 {
    use super::*;

    #[test]
    fn test_display_window_basic() -> io::Result<()> {
        // Create test files
        let test_files = create_test_files_with_id("test_display_window_basic")?;
        let basic_file = &test_files[0]; // basic_short.txt

        // Create and populate editor state
        let mut state = EditorState::new();
        state.line_count_at_top_of_window = 0;
        state.file_position_of_topline_start = 0;
        state.horizontal_line_char_offset = 0;

        // Build window map
        let lines_processed = build_windowmap_nowrap(&mut state, basic_file)?;
        assert!(lines_processed > 0, "Should process at least one line");

        // Capture output using the writer version
        let mut buffer = Vec::new();
        display_window_to_writer(&state, &mut buffer)?;

        // Convert captured output to string
        let output = String::from_utf8_lossy(&buffer);

        // Debug: print what we captured
        println!("Captured output:\n{}", output);

        // Verify content
        assert!(
            output.contains("1 Line 1: Hello, world!"),
            "Output should contain first line with line number"
        );
        assert!(
            output.lines().count() >= 18,
            "Should have at least 18 lines"
        );

        Ok(())
    }

    #[test]
    fn test_display_window_utf8() -> io::Result<()> {
        let test_files = create_test_files_with_id("test_display_window_utf8")?;
        let mixed_utf8_file = &test_files[2]; // mixed_utf8.txt

        let mut state = EditorState::new();
        state.line_count_at_top_of_window = 0;
        state.file_position_of_topline_start = 0;
        state.horizontal_line_char_offset = 0;

        // Build window map
        let lines_processed = build_windowmap_nowrap(&mut state, mixed_utf8_file)?;
        assert!(lines_processed > 0, "Should process at least one line");

        // Capture output using the writer version
        let mut buffer = Vec::new();
        display_window_to_writer(&state, &mut buffer)?;

        // Convert captured output to string
        let output = String::from_utf8_lossy(&buffer);

        // Debug: print what we captured
        println!("Captured UTF-8 output:\n{}", output);

        // Verify UTF-8 content - check the actual formatted line
        assert!(
            output.contains("1 Line 1: Hello 世界"),
            "Should handle CJK characters with line number"
        );
        assert!(
            output.contains("2 Line 2: こんにちは"),
            "Should handle Hiragana with line number"
        );

        Ok(())
    }
}

/// Debug helper for build_windowmap_nowrap test
#[cfg(test)]
mod build_window_tests3 {
    use super::*;

    #[test]
    fn test_build_windowmap_nowrap_basic() {
        // Create test file
        let test_files = create_test_files_with_id("test_build_windowmap_nowrap_basic").unwrap();
        let basic_file = &test_files[0]; // basic_short.txt

        // Create editor state
        let mut state = EditorState::new();
        state.line_count_at_top_of_window = 0;
        state.file_position_of_topline_start = 0;
        state.horizontal_line_char_offset = 0;

        // Debug: print file path
        println!("Test file path: {:?}", basic_file);
        println!("File exists: {}", basic_file.exists());

        // Build window
        let result = build_windowmap_nowrap(&mut state, basic_file);

        // Debug: print detailed error if failed
        if let Err(ref e) = result {
            println!("Build window failed: {}", e);
        }

        assert!(result.is_ok(), "Should build window successfully");

        let lines_processed = result.unwrap();
        println!("Lines processed: {}", lines_processed);

        // Debug: print buffer contents
        for i in 0..5 {
            if state.display_buffer_lengths[i] > 0 {
                let content = &state.display_buffers[i][..state.display_buffer_lengths[i]];
                println!("Row {}: {:?}", i, String::from_utf8_lossy(content));
            }
        }

        assert!(lines_processed > 0, "Should process at least one line");

        // Verify first line has content
        assert!(
            state.display_buffer_lengths[0] > 0,
            "First row should have content"
        );

        // Verify line number "1 " appears at start
        let first_row = &state.display_buffers[0];
        assert_eq!(first_row[0], b'1', "Should start with line number 1");
        assert_eq!(first_row[1], b' ', "Should have space after line number");

        // Verify WindowMap has been populated
        let map_entry = state.window_map.get_file_position(0, 2).unwrap();
        assert!(map_entry.is_some(), "Character position should be mapped");
    }
}

/// Creates test files for validating build_windowmap_nowrap functionality
///
/// # Purpose
/// Generate known-content files to verify window mapping correctness.
/// Each test gets its own unique directory to avoid race conditions.
///
/// # Arguments
/// * `test_name` - Unique identifier for this test's files
///
/// # Returns
/// * Ok(Vec<PathBuf>) - Paths to created test files
/// * Err(io::Error) - If file creation fails
fn create_test_files_with_id(test_name: &str) -> io::Result<Vec<PathBuf>> {
    use std::fs::{self, File};
    use std::io::Write;

    // Create unique test directory for this specific test
    let test_dir = PathBuf::from(format!("/tmp/lines_editor_tests_{}", test_name));
    fs::create_dir_all(&test_dir)?;

    let mut test_files = Vec::with_capacity(4);

    // Test File 1: basic_short.txt
    // Lines intentionally shorter than 77 chars (default TUI width minus line numbers)
    {
        let path = test_dir.join("basic_short.txt");
        let mut file = File::create(&path)?;

        // Each line is deliberately short (under 40 chars)
        writeln!(file, "Line 1: Hello, world!")?; // 21 chars
        writeln!(file, "Line 2: This is a test.")?; // 24 chars
        writeln!(file, "Line 3: Short line.")?; // 19 chars
        writeln!(file, "Line 4: Another short test line.")?; // 35 chars
        writeln!(file, "Line 5: Fifth line here.")?; // 25 chars
        writeln!(file, "Line 6: Almost done.")?; // 20 chars
        writeln!(file, "Line 7: Lucky seven.")?; // 20 chars
        writeln!(file, "Line 8: Eight is great.")?; // 24 chars
        writeln!(file, "Line 9: Nine is fine.")?; // 22 chars
        writeln!(file, "Line 10: Double digits!")?; // 23 chars
        writeln!(file, "Line 11: Eleven.")?; // 16 chars
        writeln!(file, "Line 12: Twelve.")?; // 16 chars
        writeln!(file, "Line 13: Thirteen.")?; // 18 chars
        writeln!(file, "Line 14: Fourteen.")?; // 18 chars
        writeln!(file, "Line 15: Fifteen.")?; // 17 chars
        writeln!(file, "Line 16: Sixteen.")?; // 17 chars
        writeln!(file, "Line 17: Seventeen.")?; // 19 chars
        writeln!(file, "Line 18: Eighteen.")?; // 18 chars
        writeln!(file, "Line 19: Nineteen.")?; // 18 chars
        writeln!(file, "Line 20: Twenty.")?; // 16 chars
        writeln!(file, "Line 21: Twenty-one.")?; // 20 chars
        writeln!(file, "Line 22: Twenty-two.")?; // 20 chars
        writeln!(file, "Line 23: Last line for now.")?; // 28 chars

        file.flush()?; // Ensure data is written
        test_files.push(path);
    }

    // Test File 2: long_lines.txt
    {
        let path = test_dir.join("long_lines.txt");
        let mut file = File::create(&path)?;

        writeln!(file, "Line 1: {}", "A".repeat(100))?;
        writeln!(
            file,
            "Line 2: The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog again."
        )?;
        writeln!(file, "Line 3: {}", "0123456789".repeat(12))?;
        writeln!(file, "Line 4: Short.")?;
        writeln!(file, "Line 5: {}", "Long_word_".repeat(15))?;

        file.flush()?;
        test_files.push(path);
    }

    // Test File 3: mixed_utf8.txt
    {
        let path = test_dir.join("mixed_utf8.txt");
        let mut file = File::create(&path)?;

        writeln!(file, "Line 1: Hello 世界")?;
        writeln!(file, "Line 2: こんにちは")?;
        writeln!(file, "Line 3: Test カタカナ Test")?;
        writeln!(file, "Line 4: Café résumé")?;
        writeln!(file, "Line 5: 한글 Korean")?;
        writeln!(file, "Line 6: Mix 中文 and English")?;
        writeln!(file, "Line 7: Numbers ０１２３４")?;

        file.flush()?;
        test_files.push(path);
    }

    // Test File 4: edge_cases.txt
    {
        let path = test_dir.join("edge_cases.txt");
        let mut file = File::create(&path)?;

        writeln!(file, "")?;
        writeln!(file, "A")?;
        writeln!(file, "\t")?;
        writeln!(file, "Before\ttab\tafter")?;
        writeln!(file, " ")?;
        writeln!(file, "    Indented")?;
        writeln!(file, "Trailing    ")?;
        writeln!(file, "")?;
        writeln!(file, "Normal line after empties")?;

        file.flush()?;
        test_files.push(path);
    }

    // Defensive: Verify all files were created and have correct size
    for path in &test_files {
        if !path.exists() {
            return Err(io::Error::new(
                io::ErrorKind::NotFound,
                format!("Test file creation failed: {:?}", path),
            ));
        }

        // Double-check file has content
        let metadata = fs::metadata(path)?;
        if metadata.len() == 0 {
            return Err(io::Error::new(
                io::ErrorKind::Other,
                format!("Test file is empty: {:?}", path),
            ));
        }
    }

    Ok(test_files)
}

// Update tests to use unique IDs:

#[cfg(test)]
mod test_file_tests3 {
    use super::*;

    #[test]
    fn test_create_test_files() {
        let result = create_test_files_with_id("test_create");
        assert!(result.is_ok(), "Should create test files successfully");

        let files = result.unwrap();
        assert_eq!(files.len(), 4, "Should create 4 test files");

        for path in &files {
            assert!(path.exists(), "File {:?} should exist", path);

            let metadata = std::fs::metadata(path).unwrap();
            assert!(metadata.len() > 0, "File {:?} should have content", path);
        }
    }

    #[test]
    fn test_basic_short_content() {
        let files = create_test_files_with_id("test_basic_short").unwrap();
        let basic_short = &files[0];

        let file = File::open(basic_short).unwrap();
        let mut reader = BufReader::new(file);
        let mut first_line = String::new();
        reader.read_line(&mut first_line).unwrap();

        let trimmed = first_line.trim_end();
        assert!(trimmed.len() < 40, "First line should be under 40 chars");
        assert_eq!(trimmed, "Line 1: Hello, world!");
    }
}

#[cfg(test)]
mod build_window_tests4 {
    use super::*;

    #[test]
    fn test_build_windowmap_nowrap_basic() {
        // Use unique test files for this test
        let test_files = create_test_files_with_id("build_window_test").unwrap();
        let basic_file = &test_files[0];

        let mut state = EditorState::new();
        state.line_count_at_top_of_window = 0;
        state.file_position_of_topline_start = 0;
        state.horizontal_line_char_offset = 0;

        let result = build_windowmap_nowrap(&mut state, basic_file);
        assert!(result.is_ok(), "Should build window successfully");

        let lines_processed = result.unwrap();
        assert!(lines_processed > 0, "Should process at least one line");

        assert!(
            state.display_buffer_lengths[0] > 0,
            "First row should have content"
        );

        let first_row = &state.display_buffers[0];
        assert_eq!(first_row[0], b'1', "Should start with line number 1");
        assert_eq!(first_row[1], b' ', "Should have space after line number");

        let map_entry = state.window_map.get_file_position(0, 2).unwrap();
        assert!(map_entry.is_some(), "Character position should be mapped");
    }
}

#[cfg(test)]
mod display_window_tests2 {
    use super::*;

    #[test]
    fn test_display_window_basic() -> io::Result<()> {
        // Use unique test files
        let test_files = create_test_files_with_id("display_basic")?;
        let basic_file = &test_files[0];

        let mut state = EditorState::new();
        state.line_count_at_top_of_window = 0;
        state.file_position_of_topline_start = 0;
        state.horizontal_line_char_offset = 0;

        let lines_processed = build_windowmap_nowrap(&mut state, basic_file)?;
        assert!(lines_processed > 0, "Should process at least one line");

        let mut buffer = Vec::new();
        display_window_to_writer(&state, &mut buffer)?;

        let output = String::from_utf8_lossy(&buffer);

        assert!(
            output.contains("1 Line 1: Hello, world!"),
            "Output should contain first line with line number"
        );

        Ok(())
    }

    #[test]
    fn test_display_window_utf8() -> io::Result<()> {
        // Use unique test files
        let test_files = create_test_files_with_id("display_utf8")?;
        let mixed_utf8_file = &test_files[2];

        let mut state = EditorState::new();
        state.line_count_at_top_of_window = 0;
        state.file_position_of_topline_start = 0;
        state.horizontal_line_char_offset = 0;

        let lines_processed = build_windowmap_nowrap(&mut state, mixed_utf8_file)?;
        assert!(lines_processed > 0, "Should process at least one line");

        let mut buffer = Vec::new();
        display_window_to_writer(&state, &mut buffer)?;

        let output = String::from_utf8_lossy(&buffer);

        assert!(
            output.contains("1 Line 1: Hello 世界"),
            "Should handle CJK characters with line number"
        );

        Ok(())
    }
}

// /// Lines - A minimal text editor for quick append-only notes
// ///
// /// # Usage
// ///   lines [FILENAME | COMMAND]
// ///
// /// # Commands
// ///   --files     Open file manager at notes directory
// ///
// /// # File Handling
// /// - Without arguments: Creates/opens yyyy_mm_dd.txt in ~/Documents/lines_editor/
// /// - With filename: Creates/opens filename_yyyy_mm_dd.txt in ~/Documents/lines_editor/
// /// - With path: Uses exact path if file exists
// fn main() -> io::Result<()> {
//     let args: Vec<String> = env::args().collect();

//     if args.len() > 1 {
//         match args[1].as_str() {
//             "files" | "--files" => {
//                 let dir_path = if args.len() > 2 {
//                     PathBuf::from(&args[2])
//                 } else {
//                     get_default_filepath(None)?
//                         .parent()
//                         .ok_or_else(|| {
//                             io::Error::new(
//                                 io::ErrorKind::NotFound,
//                                 "Could not determine parent directory",
//                             )
//                         })?
//                         .to_path_buf()
//                 };
//                 return memo_mode_open_in_file_manager(&dir_path, None);
//             }
//             _ => {}
//         }
//     }

//     // Original file editing logic...
//     let file_path = if args.len() > 1 {
//         let arg_path = PathBuf::from(&args[1]);
//         if arg_path.exists() {
//             arg_path
//         } else {
//             get_default_filepath(Some(&args[1]))?
//         }
//     } else {
//         get_default_filepath(None)?
//     };

//     editor_loop(&file_path)
// }

/// Fixed main function that properly uses command line arguments
fn main() -> io::Result<()> {
    let args: Vec<String> = env::args().collect();

    // Determine which file to display
    let file_path = if args.len() > 1 {
        // Use command line argument
        let arg_path = PathBuf::from(&args[1]);
        if arg_path.exists() && arg_path.is_file() {
            arg_path
        } else {
            // If file doesn't exist, create test files and use the first one
            println!(
                "File '{}' not found, using test file instead",
                arg_path.display()
            );
            let test_files = create_test_files_with_id("main1")?;
            test_files[0].clone()
        }
    } else {
        // No arguments: create and use test files
        println!("No file specified, using test file");
        let test_files = create_test_files_with_id("main2")?;
        test_files[0].clone()
    };

    println!("Opening file: {}", file_path.display());

    // Create and populate editor state
    let mut state = EditorState::new();
    state.line_count_at_top_of_window = 0;
    state.file_position_of_topline_start = 0;
    state.horizontal_line_char_offset = 0;

    // Build window map
    let lines_processed = build_windowmap_nowrap(&mut state, &file_path)?;
    println!("Processed {} lines", lines_processed);
    println!("{}", "-".repeat(40));

    // Display the window
    display_window(&state)?;

    Ok(())
}
