# lines_editor

Lines is a minimal text editor.